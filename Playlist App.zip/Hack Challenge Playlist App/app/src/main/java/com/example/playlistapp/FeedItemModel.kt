package com.example.playlistapp

data class FeedItemModel (
    val postTitle: String,
    val postBody: String
)
