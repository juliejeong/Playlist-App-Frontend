package com.example.playlistapp

data class NotifItemModel (
    val notifText: String,
    val timeReceived: String//don't really know of a specific data type for this yet
)